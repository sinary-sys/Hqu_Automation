#include<reg52.h>
#include"delay.h"
#include"1602.h"
#include"IIC.h"
#include"AT24C02.h"
code unsigned char string[]={"maid:piaoran  QQ:384710930"};
void main()
{
	unsigned char *s,l=0;
	LCDInit();
  wp=0;   	//�ر�д����	
  while(1)
  {
		/*���ֽ�д ���ֽڶ�*/
//		ClearSree();
//		l=0;
//		s=string;
//		while(*s)
//		{
//			AT2402_wone(1,*s);
//			Displaystring(0,0,"W:");
//			DisplayOneChar(l+2,0,*s);		
//			delay_ms(500);
//			Displaystring(0,1,"R:");
//			DisplayOneChar(l+2,1,AT2402_rone(1));
//			s++;
//			l++;
//			if(l>=14) l=0;
//		}
		/*ҳд ������*/
		ClearSree();
		Displaystring(0,0,"W:maid:pia");
		AT2402_wpage(0,string,8);
		delay_ms(500);
		AT2402_rconte(0,Rdata,8);
		Displaystring(0,1,"R:");
		s=Rdata;
 		for(l=0;l<8;l++)
		{
			DisplayOneChar(l+2,1,*s);
  		s++;
	  }
		delay_ms(1000);
		while(1);
  }
}
