#include<reg52.h>
#include"delay.h"
#include"IIC.h"
#include <intrins.h> 
/*------------------------------------------------
����IIC����
------------------------------------------------*/
void Start(void)
{
	Sda=1;
	_nop_();
	Scl=1;
	_nop_();
	Sda=0;
	_nop_();
	Scl=0;
}
/*------------------------------------------------
ֹͣIIC����
------------------------------------------------*/
void Stop(void)
{
	Sda=0;
	_nop_();
	Scl=1;
	_nop_();
	Sda=1;
	_nop_();
	Scl=0;
}


/*------------------------------------------------
���ͻ�Ӧ��IIC  ���� ������Ϊ���ͻ���Ӧ��  Ӧ���ǽ��ն˸���Ӧ���ź�
------------------------------------------------*/
void trans_Ack(void)
{
	Scl=1;
	while(Sda);
	Scl=0;
}
/*------------------------------------------------
���ջ�Ӧ��IIC  ���� ����Ҫ����Ӧ���źź�ʱ���ź�
------------------------------------------------*/
void receiv_Ack(void)
{
	Scl=0;
  Sda=0;
	_nop_();
	Scl=1;
	_nop_();
	Scl=0;
	_nop_();
}

/*------------------------------------------------
��Ӧ��IIC����
------------------------------------------------*/
void NoAck(void)
{
	Sda=1;
	_nop_();
	Scl=1;
	_nop_();
	Scl=0;
	_nop_();
}


/*------------------------------------------------
����һ���ֽ�
------------------------------------------------*/
void Send(unsigned char Data)
{ 
	unsigned char BitCounter=8;
	unsigned char temp;
	do
	{
		temp=Data;
		Scl=0;
		_nop_();
		if((temp&0x80)==0x80)
			Sda=1;
		else
			Sda=0;		
		Scl=1;
		temp=Data<<1;
		Data=temp;
		BitCounter--;
	}
	while(BitCounter);
	Scl=0;
}


/*------------------------------------------------
����һ���ֽڲ�����
------------------------------------------------*/
unsigned char Read(void)
{
	unsigned char temp=0;
	unsigned char temp1=0;
	unsigned char BitCounter=8;
	Sda=1;
	do
	{
		Scl=0;
		_nop_();
		Scl=1;
		_nop_();
		if(Sda)
			temp=temp|0x01;
		else
			temp=temp&0xfe;
		
		if(BitCounter-1)
		{
			temp1=temp<<1;
			temp=temp1;
		}
		BitCounter--;
	}
	while(BitCounter);
	Scl=0;
	return(temp);
}