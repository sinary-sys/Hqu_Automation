#include<reg51.h>
#include <intrins.h>
#include"delay.h"
sbit LED = P1^0;
#define LED_P P1
unsigned char code  a=8;
unsigned short int code b=9;
void main()
{
	unsigned char temp=0XFE;
	while(1)
	{
		LED_P=temp;
		temp=_cror_(temp,1);
		delay_ms(500);	
	}
}