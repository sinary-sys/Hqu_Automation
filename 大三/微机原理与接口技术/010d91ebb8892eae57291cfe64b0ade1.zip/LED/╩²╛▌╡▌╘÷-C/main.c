#include<reg51.h>
#include <intrins.h>
#include"delay.h"
sbit LED = P1^0;
#define LED_P P1
void main()
{
	unsigned char temp=0XFF;
	while(1)
	{
		LED_P=temp;
		temp--;
		delay_ms(500);	
	}
}