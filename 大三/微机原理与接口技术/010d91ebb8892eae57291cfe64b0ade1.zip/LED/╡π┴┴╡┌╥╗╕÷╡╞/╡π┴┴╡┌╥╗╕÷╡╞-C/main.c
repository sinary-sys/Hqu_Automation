#include<reg51.h>
sbit LED = P1^0;
unsigned char code  a=8;
unsigned short int code b=9;
void main()
{
	LED=0;
}