#include    <reg51.h>
void main()
{
//	//һ��ָ��ռ�������ֽ�
//	char *a,d='A',g;
//	int *b,e=0XFA,h;
//	long *c,f=0X9FF,i;
//	a=&g;
//	b=&h;
//	c=&i;
//	*a=d;
//	*b=e;
//	*c=f;
	

	unsigned char *a;
	unsigned char c='A';
	code const unsigned char g='B';
	a=&g;
	c=*a;
	
	
//	char xdata * data a;   /* ptr in data to xdata char */
//	int idata * data b;   /* ptr in data to idata int */
//	long code * data c;   /* ptr in data to cdata long */
//	char xdata d='A',g;
//	int idata e=0XFA,h;
//	a=&g;
//	b=&h;
//	c=0X03;
//	*a=d;
//	*b=e;
//	d=*c;
}
