#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

sbit KEY0=P3^0;
sbit KEY1=P3^1;
sbit KEY2=P3^2;
sbit KEY3=P3^3;

#define N 8
void main()
{
	unsigned short int a[N];
  unsigned short int *p=a,i,vol;
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     
		ShowSreeWord(0,0,10,"input a[]:");
		Wr_Command(0x0F,1); //���α�
		for(i=0;i<N;i++)
		{
		  vol=KEY_SCAN();
			*(p++)=vol;  //д��1  *p++�ȼ���*(P++)
//			*p++=vol;   //д��2
//			a[i]=vol;   //д��3
		  ShowoneASCII(i*2*8,16,vol);
		}
		p=a;   //����Ҫд  ����
		for(i=0;i<N;i++)
		{
		  ShowoneASCII(i*2*8,2*16,*(p++));
//			ShowoneASCII(i*2*8,2*16,*p++);
//      ShowoneASCII(i*2*8,2*16,a[i]);
		  delay_ms(300);
		}		
		while(1);
	}
}
