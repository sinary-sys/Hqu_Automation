#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

void string_sort(unsigned char *string[],unsigned char n);
void string_out(unsigned char *string[],unsigned char n);
void main()
{
	unsigned char *days[7]={"Sunday    ","Monday    ","Tuesday   ","Wednesday ","Thursday  ","Friday    ","Saturday  "};
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
    string_sort(days,7);
    string_out(days,7);		
		while(1);
	}
}
void string_sort(unsigned char *string[],unsigned char n)
{
  unsigned char * temp,i,j;
	for(i=1;i<n;i++)
	{
		for(j=0;j<n-i;j++)
		if(*string[j]>*string[j+1])
		{
			temp=string[j];
			string[j]=string[j+1];  //ֻ�ǽ�����ַ
			string[j+1]=temp;
		}
	}
}
void string_out(unsigned char *string[],unsigned char n)
{
	unsigned char i,a=0;  //Ҫ���A
  for(i=0;i<n;i++)
	{
		if(i==4)
		{
			a=0;
			ClearSree();   
		}
		ShowSreeWord(0,a*16,10,string[i]);	 //�������ָ���ַ
		a++;			
		delay_ms(1000);				
	}
}
