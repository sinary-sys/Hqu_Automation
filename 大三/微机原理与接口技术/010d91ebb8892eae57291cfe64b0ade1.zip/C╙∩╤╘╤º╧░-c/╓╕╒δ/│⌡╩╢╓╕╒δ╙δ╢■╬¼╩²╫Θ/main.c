#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

sbit KEY0=P3^0;
sbit KEY1=P3^1;
sbit KEY2=P3^2;
sbit KEY3=P3^3;

void main()
{
  unsigned short int *p,max;
  unsigned short int a[3][4]={{3,17,8,11},{66,7,8,19},{12,88,7,16}};	
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();   
    for(p=a[0],max=*p;p<a[0]+12;p++)
		{
			if(*p>max)
				max=*p;
		}
		ShowSreeWord(0,0*16,7,"OUTPUT:");
		ShowSreeWord(0,1*16,4,"MAX=");
		Show_decimalismDate(5*8,1*16,8,max);
		while(1);
	}
}
