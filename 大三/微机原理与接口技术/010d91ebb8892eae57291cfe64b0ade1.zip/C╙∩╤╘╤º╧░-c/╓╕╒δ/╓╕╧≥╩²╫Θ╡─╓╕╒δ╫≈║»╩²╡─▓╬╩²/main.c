#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

#define N 8
void main()
{
  unsigned char a[N];
	void input(unsigned char *p,unsigned char n);
	unsigned char max_a(unsigned char *p,unsigned char n);
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		ShowSreeWord(0,0,10,"input a[]:");
		Wr_Command(0x0F,1); //���α�
		input(a,N);
		ShowoneASCII(0,2*16,max_a(a,N));
		while(1);
	}
}
void input(unsigned char *p,unsigned char n)
{
	unsigned char i;
	for(i=0;i<n;i++)
	{
		*(p+i)=KEY_SCAN();
		ShowoneASCII(i*2*8,16,*(p+i));
	}
	return;
}
unsigned char max_a(unsigned char *p,unsigned char n)
{
	unsigned char i,max=*p;
	for(i=1;i<n;i++)
	{
		if(*(p+i)>max)
			max=*(p+i);
	}
	return(max);
}