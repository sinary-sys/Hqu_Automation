#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

void main()
{
  unsigned short int x,y,vol;
	void swap(unsigned short int *,unsigned short int *);
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
    ShowSreeWord(0,0,10,"input x y");
		Wr_Command(0x0F,1); //���α�		
		vol=KEY_SCAN();		
		x=vol;
		ShowoneASCII(0*8,16,vol);
		vol=KEY_SCAN();		
		y=vol;
		ShowoneASCII(8*8,16,vol);
		if(x<y)
			swap(&x,&y);
		ShowoneASCII(0*8,2*16,x);
		ShowoneASCII(8*8,2*16,y);
		while(1);
	}
}
void swap(unsigned short int *p1,unsigned short int *p2)
{
	unsigned short int temp;
	temp=*p1;
	*p1=*p2;
	*p2=temp;
}
