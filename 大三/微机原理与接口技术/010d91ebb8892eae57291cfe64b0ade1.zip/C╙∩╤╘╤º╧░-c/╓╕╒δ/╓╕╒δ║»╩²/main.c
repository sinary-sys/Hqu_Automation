#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"string.h"
unsigned char *max_lenth(unsigned char *string[],unsigned char n);
void main()
{
	unsigned char *p;
	unsigned char *days[7]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		p=max_lenth(days,7);
		ShowSreeWord(0,0*16,10,p);
		while(1);
	}
}
unsigned char *max_lenth(unsigned char *string[],unsigned char n)
{
	unsigned char i,posion,max_l;
	posion=0;
	max_l=strlen(string[0]);
	for(i=1;i<n;i++)
	  if(strlen(string[i])>max_l)
		{
			max_l=strlen(string[i]);
			posion=i;
		}
	return(string[posion]);
}