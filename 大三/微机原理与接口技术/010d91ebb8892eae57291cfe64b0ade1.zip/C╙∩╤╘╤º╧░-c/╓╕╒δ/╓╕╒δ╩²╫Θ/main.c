#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
void main()
{
  unsigned short int i,a;
	unsigned char *days[7]={"Sunday    ","Monday    ","Tuesday   ","Wednesday  ","Thursday  ","Friday    ","Saturday  "};
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
    for(i=0;i<7;i++)
		{
			if(i==4)
			{
				a=0;
				ClearSree();   
			}
      ShowSreeWord(0,a*16,10,days[i]);	 //�������ָ���ַ
			a++;			
			delay_ms(1000);				
		}
		while(1);
	}
}
