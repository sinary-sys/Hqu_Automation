#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
void main()
{
  unsigned char i,a[10]={33,12,97,3,7,18,9,51};
	void swap(unsigned char *,unsigned char *);
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		for(i=0;i<8;i++)
		{
			Show_decimalismDate(i>3?(i-4)*2*16:i*2*16,i>3?1*16:0*16,8,a[i]);
		  delay_ms(300);
		}		
		for(i=0;i<7;i++)
		  if(a[i]>a[i+1])
				swap(&a[i],&a[i+1]);
		for(i=0;i<8;i++)
		{
			Show_decimalismDate(i>3?(i-4)*2*16:i*2*16,i>3?3*16:2*16,8,a[i]);
		  delay_ms(300);
		}		
		while(1);
	}
}
void swap(unsigned char *p1,unsigned char *p2)
{
	unsigned char temp;
	temp=*p1;
	*p1=*p2;
	*p2=temp;
}
