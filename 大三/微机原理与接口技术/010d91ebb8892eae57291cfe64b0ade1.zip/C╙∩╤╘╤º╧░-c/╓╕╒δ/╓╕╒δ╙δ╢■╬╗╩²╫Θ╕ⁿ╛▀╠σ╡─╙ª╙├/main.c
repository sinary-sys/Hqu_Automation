#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

sbit KEY0=P3^0;
sbit KEY1=P3^1;
sbit KEY2=P3^2;
sbit KEY3=P3^3;

void main()
{
  unsigned short int a[3][4]={{3,17,8,11},{66,7,8,19},{12,88,7,16}};	
  unsigned short int *p=a[0],max=a[0][0],i,j,row=0,col=0;
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();   
    for(i=0;i<3;i++)
		{
      for(j=0;j<4;j++)
			{
				if(*(p+i*4+j)>max)
				{
					max=*(p+i*4+j);
					row=i;
					col=j;
				}
			}
		}
		ShowSreeWord(0,0*16,7,"OUTPUT:");
		ShowSreeWord(0,1*16,4,"MAX=");
		Show_decimalismDate(5*8,1*16,8,max);
		ShowSreeWord(0,2*16,4,"row=");
		Show_decimalismDate(5*8,2*16,8,row);
		ShowSreeWord(0,3*16,4,"col=");
		Show_decimalismDate(5*8,3*16,8,col);
		while(1);
	}
}
