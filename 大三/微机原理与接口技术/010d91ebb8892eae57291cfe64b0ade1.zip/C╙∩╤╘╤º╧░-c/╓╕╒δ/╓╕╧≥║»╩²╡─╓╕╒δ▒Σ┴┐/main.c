#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
unsigned short int max(unsigned short int x,unsigned short int y);
void main()
{
	unsigned short int a,b,c;
  unsigned short int (*pf)(unsigned short int x,unsigned short int y);	
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		ShowSreeWord(0,0,10,"input a[]:");
		Wr_Command(0x0F,1); //���α�
    pf=max;
		a=KEY_SCAN();
		ShowoneASCII(0,16,a);
		b=KEY_SCAN();
		ShowoneASCII(8*8,16,b);
		c= (* pf)(a,b);
		ShowoneASCII(0,2*16,c);		
		while(1);
	}
}
unsigned short int max(unsigned short int x,unsigned short int y)
{
	return(x>y?x:y);
}