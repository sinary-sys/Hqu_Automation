#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"

#define N 8
void main()
{
  unsigned char a[10],b[20];
	unsigned char *pa=a,*pb=b;
	void input(unsigned char *p,unsigned char n);
  void copy_s(unsigned char *str1,unsigned char *str2);
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		ShowSreeWord(0,0,10,"input a[]:");
		Wr_Command(0x0F,1); //���α�
		input(a,N);
//		copy_s(a,b);
		copy_s(pa,pb);
		ShowSreeWord(0,2*16,10,b);
		while(1);
	}
}
void input(unsigned char *p,unsigned char n)
{
	unsigned char i;
	for(i=0;i<n;i++)
	{
		*(p+i)=KEY_SCAN();
		ShowoneASCII(i*2*8,16,*(p+i));
	}
	return;
}
void copy_s(unsigned char *str1,unsigned char *str2)
{
  while((*str2=*str1)!='\0')
	{
		str1++;
		str2++;
	}
}
