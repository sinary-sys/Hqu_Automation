#include<reg52.h>
#include<stdio.h>
#include<stdlib.h>
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct s_node
{
	unsigned short int num;
	unsigned short int score;
	struct s_node *next;
};

struct s_node* create_node(void);
struct s_node* create_list(unsigned char n);
void out_list(struct s_node *head);
void main()
{
	struct s_node *head=NULL;
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
  delay_ms(10);
	while(1)
	{
		head=create_list(2);
		out_list(head);
		while(1);
	}
}
struct s_node* create_node(void)
{
	unsigned char vol,i;
  struct s_node *p;
	p=(struct s_node *)malloc(sizeof(struct s_node)); 
	ClearSree();     //Һ������
  delay_ms(10);
	ShowSreeWord(0,0,10,"input num:");
	Wr_Command(0x0F,1); //���α�
	p->num=0X0000;
	for(vol=0;vol<2;vol++)
	{
	  p->num=KEY_SCAN();
		Show_decimalismDate(vol*3*8,16,8,p->num);	
	}
	ShowSreeWord(0,2*16,12,"input score:");
	p->score=0X0000;
  for(vol=0;vol<2;vol++)
	{
		i=KEY_SCAN();
	  p->score=i+((p->score)<<4);
		ShowoneASCII(vol*2*8,3*16,i);
	}
	p->next=NULL;
	return(p);
}
struct s_node* create_list(unsigned char n)
{
  struct s_node *p,*newe;	
	struct s_node *head;
	unsigned char i;
	if(n>=1)
	{
		newe=create_node();
		head=newe;
		p=newe;
	}
	for(i=2;i<=n;i++)
	{
		newe=create_node();
    p->next=newe;
		p=newe;
	}
  if(n>=1)
	{
    return(head); 
	}
	else
		return(NULL); 
}
void out_list(struct s_node *head)
{
  struct s_node *p;	
	if(head!=NULL)
	{
		p=head;
		while(p!=NULL)
		{
			ClearSree();     //Һ������
			delay_ms(10);
			Show_decimalismDate(0,0,6,p->num);	
			Show_decimalismDate(0,16,6,p->score);		
			p=p->next;
			delay_ms(1000);
		}
	}
}

