#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct student
{
	unsigned short int num;
	unsigned char name[20];
	unsigned char sex;
	unsigned short int score;
};
void main()
{
	struct student stu={9011,"liujia",'M',87};   //��������ֵ
	LcdInit();	  //Һ����ʼ��
	while(1)
	{
		ClearSree();     //Һ������
		ShowSreeWord(0,0,6,stu.name);
		Show_decimalismDate(0,16,5,stu.score);
		while(1);
	}
}