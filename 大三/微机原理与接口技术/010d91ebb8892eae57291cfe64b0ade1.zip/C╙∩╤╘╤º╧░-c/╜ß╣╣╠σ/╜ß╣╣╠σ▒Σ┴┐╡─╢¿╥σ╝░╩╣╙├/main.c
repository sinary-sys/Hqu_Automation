#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct student
{
	unsigned short int num;
	unsigned char name[20];
	unsigned char sex;
	unsigned short int score;
}stu1={9011,"liujia",'W',87},stu2={9012,"chengdong",'M',97};
void main()
{
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	while(1)
	{
		if(stu1.score>=stu2.score)
		{
			ShowSreeWord(0,0,6,stu1.name);
			Show_decimalismDate(0,16,5,stu1.score);
		}
		else
		{
			ShowSreeWord(0,0,9,stu2.name);
			Show_decimalismDate(0,16,5,stu2.score);			
		}
		while(1);
	}
}