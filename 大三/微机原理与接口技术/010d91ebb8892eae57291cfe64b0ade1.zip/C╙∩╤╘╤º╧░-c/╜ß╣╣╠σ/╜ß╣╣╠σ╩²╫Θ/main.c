#include<reg52.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct  student
{
	unsigned short int num;
	unsigned char name[10];
	unsigned char sex;
	unsigned short int score;
};
void main()
{
	struct student code stu[5]={{9011,"jinfang   ",'W',87},{9012,"huijie    ",'M',97},{9013,"lihong    ",'W',96},{9014,"chengdong ",'M',100},{9015,"wanglu    ",'M',94}};
	unsigned short int i,count_m=0,count_f=0,a=0;
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
  delay_ms(10);
	while(1)
	{
		for(i=0;i<5;i++)
		{
			if(stu[i].score>=96)
			{
			  ShowSreeWord(0,a*16,10,stu[i].name);				
				Show_decimalismDate(11*8,a*16,7,stu[i].score);	
				a++;
				if(stu[i].sex=='M')
					count_m++;
				else
					count_f++;
			}
		}
		Show_decimalismDate(0,3*16,7,count_m);
		Show_decimalismDate(8*8,3*16,7,count_f);		
		while(1);
	}
}