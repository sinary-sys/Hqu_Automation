#include<reg52.h>
#include<string.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct  student
{
	unsigned short int num;
	unsigned char name[10];
	unsigned char sex;
	unsigned short int score;
};
void output(struct student *p,unsigned short int n);
void main()
{
	struct student code stu[5]={{9011,"jinfang   ",'W',87},{9012,"huijie    ",'M',97},{9013,"lihong    ",'W',96},{9014,"chengdong ",'M',100},{9015,"wanglu    ",'M',94}};
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
  delay_ms(10);
	while(1)
	{
    output(stu,3);
		while(1);
	}
}
void output(struct student *p,unsigned short int n)
{
	unsigned short int i;
	for(i=0;i<n;i++,p++)
	{
		ClearSree();     //Һ������
		delay_ms(10);
		Show_decimalismDate(0,0,6,p->num);	
		ShowSreeWord(0,16,10,p->name);	
		ShowSreeWord(0,2*16,1,&p->sex);
		Show_decimalismDate(0,3*16,7,p->score);		
		delay_ms(1000);			
	}
}
	