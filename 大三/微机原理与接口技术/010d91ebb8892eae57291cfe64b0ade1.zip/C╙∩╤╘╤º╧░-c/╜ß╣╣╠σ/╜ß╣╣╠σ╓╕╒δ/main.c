#include<reg52.h>
#include<string.h>
#include"Picture.h"
#include"lcd12864.h"
#include"delay.h"
#include"KEY.H"
struct  student
{
	unsigned short int num;
	unsigned char name[10];
	unsigned char sex;
	unsigned short int score;
};
void main()
{
	struct student stu,*p;
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
  delay_ms(10);
	while(1)
	{
		p=&stu;
		p->num=9911;
		strcpy(p->name,"changjiang");
		p->sex='F';
		p->score=91;
		Show_decimalismDate(0,0,6,p->num);	
		ShowSreeWord(0,16,10,p->name);	
		ShowSreeWord(0,2*16,1,&p->sex);
		Show_decimalismDate(0,3*16,7,p->score);					
		while(1);
	}
}