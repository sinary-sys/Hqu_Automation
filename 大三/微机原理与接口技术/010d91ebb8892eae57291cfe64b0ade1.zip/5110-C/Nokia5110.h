void Serial_init(void);
void LCD_init(void);
void LCD_write_byte(unsigned char dat, unsigned char command);
void LCD_clear(void);
void LCD_set_XY(unsigned char X, unsigned char Y);
void LCD_6X8char(unsigned char X,unsigned char Y,unsigned char c);
void LCD_6X12char(unsigned char X,unsigned char Y,unsigned char c);
void LCD_8X16char(unsigned char X,unsigned char Y,unsigned char c);
void LCD_englis_6X8str(unsigned char X,unsigned char Y,char *s);
void LCD_englis_8X16str(unsigned char X,unsigned char Y,char *s);
void LCD_draw_bmp_pixel(unsigned char X,unsigned char Y,unsigned char *map,unsigned char Pix_x,unsigned char Pix_y);
void LCD_chines_fixati_12X12str(unsigned char X, unsigned char Y,unsigned char num,unsigned char (*word)[24]);   //**word
void LCD_chines_fixati_16X16str(unsigned char X, unsigned char Y,unsigned char num,unsigned char (*word)[32]);
void LCD_chines_16X16str(unsigned char X, unsigned char Y, unsigned char c[2]);
void LCD_chines_12X12str(unsigned char X, unsigned char Y, unsigned char c[2]);
void LCD_16X16Str(unsigned short int x,unsigned short int y,unsigned char *s);
void LCD_12X12Str(unsigned short int x,unsigned short int y,unsigned char *s);
void Show_hexadecimalDate(char x, unsigned char y,unsigned char arrayOffset,unsigned long int date);
void Show_decimalismDate(char x, unsigned char y,unsigned char arrayOffset,unsigned long int date);
