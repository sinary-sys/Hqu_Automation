#include<reg52.h>
#include<INTRINS.h>
#include"delay.h"
/*******************************************************************************
* Function Name  : delay_ms
* Description    : ������ʱ����
* Input          : nҪ��ʱ���ٺ���
* Output         : None
* Return         : None
* Data           : 2014/6/13
* programmer     : piaoran
* remark         ������  delay_ms(1000);	
*******************************************************************************/
void delay_ms(unsigned int n)
{
	unsigned int i,j;
	for(i=0;i<n;i++)
	for(j=0;j<123;j++);    //89C51
//	for(j=0;j<1005;j++);    //12C5A60S2
//	for(j=0;j<1150;j++);    //15F101W
}
/*******************************************************************************
* Function Name  : delay_ms
* Description    : ΢����ʱ����
* Input          : nҪ��ʱ����΢��
* Output         : None
* Return         : None
* Data           : 2014/8/31
* programmer     : piaoran
* remark         ������  delay_us(1000);	
*******************************************************************************/
void delay_us(unsigned int n)
{
	while (n--);   //12C5A60S2
//	unsigned int i;
//	for(i=0;i<n;i++)
//	  _nop_();
}