#include<reg52.h>
#include"delay.h"
#include"1602.h"
void main(void)
{
  LCDInit();
	DisplayOneChar(0,0,'A');
	Displaystring(0,1,"maid:piaoran");
	delay_ms(1000);
	ClearSree();
	Show_decimalismDate(0,0,5,1000);
	Show_hexadecimalDate(0,1,3,0X01FA8E);
	while(1)
	{
    
	}
}
