#include<reg52.h>
#include"delay.h"
#include"KEY.h"
#include"led-display.h"
signed char num=0;  //��ΪҪ����������С ��������ط��������з��ŵ���
void main(void)
{
	unsigned char i=0,sel=0,num,ok=0,wei=7,temp=0;
	unsigned short int j=0XFFF;
	while(1)
	{
		while(j--)
		{
			if(!key1)
			{
				delay_ms(20);	
				if(!key1)
				{
					j=0;
					num++;
					temp=1;
				}
				while(!key1);
				delay_ms(20);	
				while(!key1);
			}
			else if(!key2)
			{
				j=0;
				num--;
				temp=2;
			}
			else if(!key3)
			{
				j=0;
				sel=1;
				temp=3;
			}
			else if(!key4)
			{
				j=0;
				ok=1;
			}
	  }
		j=0XFFF;
		if(temp==1)
		{
			P2=wei;
			P0=numtab[num];
			if(num>9) num=0;
		}
		if(temp==2)
		{
			P0=numtab[num];
			P2=wei;
			if(num>9) num=0;
		}
		if(temp==3)
		{
      wei=6;
		}
     if(temp==3)
		{
      wei=1;
		}
	}
}
