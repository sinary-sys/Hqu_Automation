#include<reg52.h>
#include"KEY.h"
#include"delay.h"
#include<INTRINS.h>
void main(void)
{
	unsigned char a,temp=0XFC;
	while(1)
	{
		a=key();
		if(a==1)
		{
			P1=0XF0;
			delay_ms(500);	
			P1=0XFF;
			delay_ms(500);	
		}
		if(a==2)
		{
			P1=0X0F;
			delay_ms(500);	
			P1=0XFF;
			delay_ms(500);	
		}
		if(a==3)
		{
			temp= _cror_ (temp,1);
			P1=	temp;
			delay_ms(500);	
		}
		if(a==4)
		{
			temp= _crol_ (temp,1);
			P1=	temp;
			delay_ms(500);	
		}
	}
}