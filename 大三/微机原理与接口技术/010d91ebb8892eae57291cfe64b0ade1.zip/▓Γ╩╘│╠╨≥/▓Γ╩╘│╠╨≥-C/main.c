#include<reg52.h> 
#include<INTRINS.h>
sbit LED_0=P1^0;
void delay_nms(unsigned int n);
void delay_nus(unsigned int n);
void DelayMs(unsigned int x)   //0.14ms��� 0us
{
	unsigned char i;
	while(x--)
	{
		for (i = 0; i<13; i++)
		{}
	}
}

void main()
{
//	EX0=1;    //�����ⲿ�ж�0
//	IT0=1;    //������ʽΪ�½��ش���	
//	EA=1;    
//	INMAIBO=1;
	while(1)
	{
		P0=0X00;
		P1=0X00;
		P2=0X00;
		P3=0X00;
		delay_nms(500);
	//	delay_nus(10);
		P0=0XFF;
		P1=0XFF;
		P2=0XFF;
		P3=0XFF;
		delay_nms(500);
	//  delay_nus(10);
		
//		LED_0=0;
//		delay_nus(140);
////		DelayMs(1);
//		LED_0=1;
//		delay_nus(140);
////		DelayMs(1);
	}
}
void delay_nms(unsigned int n)
{
	unsigned int i,j;
	for(i=0;i<n;i++)
	for(j=0;j<123;j++);    //89C51
//	for(j=0;j<1005;j++);    //12C5A60S2
//	for(j=0;j<1150;j++);    //15F101W
}
void delay_nus(unsigned int n)
{
//	while (n--);
//	unsigned int i;
//	for(i=0;i<n;i++)
//	  _nop_();
}

//void exter0() interrupt 0  //�͵�ƽ����
//{
//	P0=0XFF;
//	P1=0XFF;
//	P2=0XFF;
//	//P3=0XFF;
//	delay_nms(1000);	 
//}