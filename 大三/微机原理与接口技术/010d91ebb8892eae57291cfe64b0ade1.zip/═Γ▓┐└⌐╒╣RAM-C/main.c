#include<reg52.h>
#include"delay.h"
#include <absacc.h>
#include"RAM.h"
unsigned char TX[20];
unsigned char RX[20];
sfr AUXR=0X8E;   //�����Ĵ���
void main()
{
  unsigned short int DPTR;
	unsigned char i;
	AUXR=0x02;   //��ֹ�ڲ�RAM
	for(i=0;i<20;i++)
	{
		TX[i]=i;
	}
	while(1)
	{
		DPTR=0X6FFF;
		for(i=0;i<20;i++)   //д
		{
			Write_Byte(DPTR,TX[i]);
			DPTR++;
		}
		DPTR=0X6FFF;
		for(i=0;i<20;i++)  //��
		{
			RX[i]=Read_Byte(DPTR);
			DPTR++;
		}
		for(i=0;i<20;i++)   //�Ƚ�
		{
			if(RX[i]==TX[i])
			{
				P1=0XF0;
			}
			else
			{
				P1=0X0F;
			}
		}
//		Write_Byte(DPTR,0XA0);
//    P1=Read_Byte(DPTR);
		delay_ms(500);
	}
}


