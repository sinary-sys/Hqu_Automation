#include"STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include"ADC.h"
#include"rocker.h"
void main()
{
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	delay_ms(500);	
	InitADC(0);                      //Init ADC sfr
	while(1)
	{
		Get_coord();
		ClearSree();
		Show_coord();
		delay_ms(100);	
	}
}
