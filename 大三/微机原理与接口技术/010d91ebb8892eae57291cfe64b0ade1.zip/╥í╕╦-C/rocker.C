#include"STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include"ADC.h"
#include"rocker.h"
unsigned short int x,y;
/*******************************************************************************
* Function Name  : Get_coord
* Description    : ��ȡҡ�����꺯��
* Input          : None
* Output         : x  X����  ��ΧΪ0-1023  ҡ�˲���ʱ��ΪΪһ�� 650����
                   y  Y����
* Return         : None
* DATA           : 2014/12/23
* programmer     : piaoran  QQ:384710930
* remark         ��Get_coord();
*******************************************************************************/
void Get_coord(void)
{
	x=GetADCResult(4);
	y=GetADCResult(5);
	Show_decimalismDate(2*8,0,6,x);
	Show_decimalismDate(2*8,16,6,y);
}
/*******************************************************************************
* Function Name  : Show_coord
* Description    : ��ʾҡ�����꺯��
* Input          : None
* Output         : None
* DATA           : 2014/12/23
* programmer     : piaoran  QQ:384710930
* remark         ��Get_coord();
*******************************************************************************/
void Show_coord(void)
{
	ShowSreeWord(0,0,2,"X:");
	ShowSreeWord(0,16,2,"Y:");
	Show_decimalismDate(2*8,0,6,x);
	Show_decimalismDate(2*8,16,6,y);
	ShowoneASCII(y/16+48,x/16,0X02);
}
