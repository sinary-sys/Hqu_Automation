#include"STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include"ADC.h"
void main()
{
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	delay_ms(500);	
	ShowSreeWord(0,0,4,"ADC:");
	ShowSreeWord(0,16,2,"V:");
	InitADC(0);                      //Init ADC sfr
	while(1)
	{
		adc=GetADCResult(0);
		volta=adc*VREF/1023;
		Show_decimalismDate(4*8,0,6,adc);
		Wr_Command(0x91,1); //�ڶ��еڶ�����
		Wr_Data(volta+'0');
		Wr_Data('.');
		volta=volta*1000;
		volta=(unsigned short int)volta%10000;
		Show_decimalismDate(4*8,16,7,volta);
    delay_ms(500);	
	}
}
