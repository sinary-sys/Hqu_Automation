#include"STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include"ADC.h"
void main()
{
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	delay_ms(500);	
	ShowSreeWord(0,0,4,"ADC:");
	ShowSreeWord(0,16,2,"V:");
	InitADC(0);                     //Init ADC sfr
	while(1)
	{
     ADC_start(0);
		 delay_ms(500);	
	}
}
