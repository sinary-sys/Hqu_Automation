#include "STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include"Picture.h"
#include <absacc.h>
void main()
{
	unsigned short int i;
	unsigned char *s,*r;
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	delay_ms(500);	
  ShowSreeWord(0,0,6,"Write:");
	ShowSreeWord(0,16,12,"dat:    Add:");
	ShowSreeWord(0,32,5,"Read:");
  ShowSreeWord(0,48,12,"dat:    Add:");	
	AUXR =0X00;
	s=mountain_CD128X64;
	for(i=0;i<0X03FF;i++)
	{
		XBYTE[i]=*s;
		Show_hexadecimalDate(4*8,16,6,*s);
		Show_hexadecimalDate(12*8,16,4,(unsigned long int)s);
		delay_ms(10);	
		*r=XBYTE[i];
		Show_hexadecimalDate(4*8,48,6,*r);
		Show_hexadecimalDate(12*8,48,4,i);
		s++;
	}
	ClearSree(); 
	delay_ms(500);
	ShowSreeAllPic(XBYTE);
	while(1)
	{
	}
}
