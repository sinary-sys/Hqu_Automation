#include "STC15F2K.h"
#include"lcd12864.h"
#include"delay.h"
#include "EEPROM.h"
void main()
{
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	delay_ms(500);	
	ShowSreeWord(0,0,6,"Write:");
	ShowSreeWord(0,16,1,"A");
//	IapProgramByte(0,'A');
  ShowSreeWord(0,32,5,"Read:"); 
	ShowoneASCII(0,48,IapReadByte(0)); 
	while(1)
	{
    
	}
}
