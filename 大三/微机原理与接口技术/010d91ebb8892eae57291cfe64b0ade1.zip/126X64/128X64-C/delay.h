#ifndef __delay_H__
#define __delay_H__

void delay_ms(unsigned int n);   //��� -0.651041666667us
void delay_us(unsigned int n);   //��� -0.000000000227us

#endif