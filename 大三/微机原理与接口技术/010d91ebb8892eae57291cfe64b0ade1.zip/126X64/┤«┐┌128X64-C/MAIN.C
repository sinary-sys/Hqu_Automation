#include <reg52.H>
#include"lcd12864.h"
#include"delay.h"
void main(void)
{
	initial_lcd();
	clear_screen();  
	delay_ms(500);
	display_string_8x16(1,1,"0123456789abcdef");
	while(1)
	{
	}
}
