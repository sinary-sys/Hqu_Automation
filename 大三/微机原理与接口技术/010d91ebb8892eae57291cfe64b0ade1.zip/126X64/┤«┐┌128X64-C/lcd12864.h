#ifndef __lcd12864_H__
#define __lcd12864_H__
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long
	
extern unsigned char code integer[16];
void transfer_command(int data1);
void transfer_data(int data1);
void initial_lcd();
void clear_screen();
void full_display();
void lcd_address(uchar page,uchar column);
void display_graphic_32x32(uchar page,uchar column,uchar *dp);
void display_graphic_16x16(uchar page,uchar column,uchar *dp);
void display_graphic_8x16(uchar page,uchar column,uchar *dp);
void display_string_8x16(uint page,uint column,uchar *text);
void display_string_5x7(uint page,uint column,uchar *text);
#endif