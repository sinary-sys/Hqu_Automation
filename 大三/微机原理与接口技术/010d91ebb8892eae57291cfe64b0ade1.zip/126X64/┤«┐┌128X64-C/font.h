extern unsigned char code ascii_table_8x16[95][16];
extern unsigned char code ascii_table_5x7[95][5];