/*����Ŀ��ͷ�ļ�*/

#ifndef __SERIAL_H
#define __SERIAL_H

#ifdef  OS_CPU_GLOBALS
#define OS_CPU_EXT
#else
#define OS_CPU_EXT  extern
#endif


/*Serial port send buffer struct */
typedef struct
{
 unsigned char* buffer;
 int		ptr;
 int   		count;
}SerialBuffer;

OS_CPU_EXT SerialBuffer pc_send;

void SendStr(unsigned char* buffer,int count);


#endif //__SERIAL_H
