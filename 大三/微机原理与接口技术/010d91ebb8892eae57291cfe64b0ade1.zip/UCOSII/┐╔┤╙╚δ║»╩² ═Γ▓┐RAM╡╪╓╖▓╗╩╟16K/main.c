#include    <reg51.h>
int fun(char a,char b,char c,char d) reentrant;
void main()
{
	int i;
	i=fun(1,2,3,4);
}
int fun(char a,char b,char c,char d) reentrant
{
	int j1,j2;
	j1=a+b+c+d;
	j2=j1+10;
	return j2;
}