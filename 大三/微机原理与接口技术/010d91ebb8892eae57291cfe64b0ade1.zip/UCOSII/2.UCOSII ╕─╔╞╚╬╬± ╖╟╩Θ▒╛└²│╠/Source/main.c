#include "includes.h"
#include "serial.h"
sfr AUXR        =   0x8E;   //0000,0000 �����Ĵ���
sbit LED1=P1^0;
sbit LED2=P1^1;
sbit LED3=P1^2;
sbit LED4=P1^3;
sbit LED5=P1^4;
sbit LED6=P1^5;
sbit LED7=P1^6;
sbit LED8=P1^7;
unsigned char xdata strbuf[8];
//��������������û���ջ�ͷ����ջ
OS_STK xdata  TaskStartStk1[50];
OS_STK xdata  XBPTask1[50];

OS_STK xdata  TaskStartStk2[50];
OS_STK xdata  XBPTask2[30];

OS_STK xdata  TaskStartStk3[45];
OS_STK xdata  XBPTask3[30];

void Task1(void *nouse) reentrant;
void Task2(void *nouse) reentrant;
void Task3(void *nouse) reentrant;

void DecTochar(unsigned int n,unsigned char *buf) 
{
	unsigned char i;
	unsigned char buffer[8];
	for(i=0;i<5;i++)
	{
	buffer[i]=n%10+0x30;
	n=n/10;
	if(n==0)break;
	}
	for(;i>0;i--)*buf++=buffer[i];
	*buf++=buffer[i];
	*buf++='\r';
	*buf++='\n';
	*buf='\0';
}

void  InitTaskXBPStk_ALL()
{
	InitTaskXBPStk(OSTaskIdleStk,XBPIdleSta,TASK_IDLE_XBPSTK_SIZE);
#if OS_TASK_STAT_EN > 0
	InitTaskXBPStk(OSTaskStatStk,XBPStartStk,TASK_STAT_XBPSTK_SIZE);
#endif	
	InitTaskXBPStk(TaskStartStk1,XBPTask1,50);
	InitTaskXBPStk(TaskStartStk2,XBPTask2,30);
	InitTaskXBPStk(TaskStartStk3,XBPTask3,30);
}


void main(void)
{
	AUXR =0X00;
	InitTaskXBPStk_ALL();
	OSInit();
	InitHardware();	
	OSTaskCreateExt(Task1, (void *)0, &TaskStartStk1[0],2,2,&TaskStartStk1[49],50,(void *)0,OS_TASK_OPT_STK_CHK);	
	OSTaskCreateExt(Task2, (void *)0, &TaskStartStk2[0],3,3,&TaskStartStk2[49],50,(void *)0,OS_TASK_OPT_STK_CHK);
	OSTaskCreateExt(Task3, (void *)0, &TaskStartStk3[0],4,4,&TaskStartStk3[44],45,(void *)0,OS_TASK_OPT_STK_CHK);
	OSStart();
}

void Task1(void *nouse) reentrant
{
  unsigned char code Str0[]="Welcome to MCU123.COM \r\n";
 	unsigned char code Str1[]="Task1 is running! LED1=ON \r\n\n";
 	unsigned char code Strv[]="uCosII_Ver";
	OS_STK_DATA STKdata;
	OS_STK_DATA XBPdata; 
	nouse=nouse;  
  SendStr(Str0, sizeof(Str0));
	DecTochar(OSVersion(),strbuf);
	SendStr(Strv,sizeof(Strv));
	SendStr(strbuf, strlen(strbuf));
	EA=1;
	TR0=1;
	for(;;)
	{
			LED1 = 0;
			LED2 = 0;
			SendStr(Str1, sizeof(Str1));

	OSTaskStkChk(OS_PRIO_SELF, &STKdata);	
	SendStr("     Task1 user STK ", 20);
	DecTochar(STKdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));
	XBPStkChk (OS_PRIO_SELF, &XBPdata);
	SendStr("     Task1 user XBP ", 20);
	DecTochar(XBPdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));

	OSTaskStkChk(3, &STKdata);	
	SendStr("     Task2 user STK ", 20);
	DecTochar(STKdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));
	XBPStkChk (3, &XBPdata);
	SendStr("     Task2 user XBP ", 20);
	DecTochar(XBPdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));

	OSTaskStkChk(4, &STKdata);	
	SendStr("     Task3 user STK ", 20);
	DecTochar(STKdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));
	XBPStkChk (4, &XBPdata);
	SendStr("     Task3 user XBP ", 20);
	DecTochar(XBPdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));

	OSTaskStkChk(OS_IDLE_PRIO, &STKdata);	
	SendStr("     IDLE_Task user STK ", 24);
	DecTochar(STKdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));
	XBPStkChk (OS_IDLE_PRIO, &XBPdata);
	SendStr("     IDLE_Task user XBP ", 24);
	DecTochar(XBPdata.OSUsed,strbuf);
	SendStr(strbuf, strlen(strbuf));

			OSTimeDly(OS_TICKS_PER_SEC*6);
    }    
}

void Task2(void *nouse) reentrant
{  unsigned char code Str2[]="Task2 is running! LED2=ON \r\n\n";
    nouse=nouse;
    for(;;)
    {
		    LED3 = 0;
			  LED4 = 0;
        SendStr(Str2, sizeof(Str2));
        OSTimeDly(OS_TICKS_PER_SEC*6);
    }
}

void Task3(void *nouse) reentrant
{  unsigned char code Str3[]="Task3 is running! LED1=OFF LED2=OFF \r\n\n";
    nouse=nouse;
    for(;;)
    {
				LED1 = 1;
				LED2 = 1;
			  LED3 = 1;
			  LED4 = 1;
        SendStr(Str3, sizeof(Str3));
        OSTimeDly(OS_TICKS_PER_SEC*3);
    }
}