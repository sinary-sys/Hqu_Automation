#include"voltmeter.h"
#include<led-display.h>
#include"delay.h"
float volta=3.892,VREF=4.89;
/*******************************************************************************
* Function Name  : led_displa_voltag
* Description    : �����������ʾһλ���� ��λС�� �ĵ�ѹֵ
* Input          : voltag Ҫ��ʾ��С�� 
* Output         : None
* Return         : None
* DATA           : 2014/11/24
* programmer     : piaoran  QQ:384710930
* remark         ��led_displa_voltag(volta);
*******************************************************************************/
void led_displa_voltag(float voltag)
{
	unsigned short int temp=0;
	temp=(unsigned short int)voltag;
	LED138=(LED138&0XF8)+0X04;
	LED_LOK=1;
	LED_wei=numtab[temp]|0X80;//��ʾС����
	LED_LOK=0;
	temp=(unsigned short int)((float)voltag*1000)%10000;
  led_display_decimalism(temp,0,3,0);
}
/*******************************************************************************
* Function Name  : addlok
* Description    : ����ͨ����ַ 0��7
* Input          : add ͨ����
* Output         : None
* Return         : None
* DATA           : 2014/11/24
* programmer     : piaoran QQ:384710930
* remark         ��addlok(0);
*******************************************************************************/
void addlok(unsigned char add)
{
	ALE=0;
	add=(add&0X07);
	ADC_0=add&0x01;
	ADC_1=(add&0x02)>>1;
	ADC_2=(add&0x04)>>2;
	ALE=1;
}
/*******************************************************************************
* Function Name  : addlok
* Description    : AD��ʼ������
* Input          : add ͨ����
* Output         : None
* Return         : None
* DATA           : 2014/11/24
* programmer     : piaoran QQ:384710930
* remark         ��ADINIT(0);
*******************************************************************************/
void ADINIT(unsigned char add)
{
	TMOD |= 0x20;
	TH1  = 0x14;
	TL1  = 0x14;
	EA=1;				     
	ET1=1;        
	TR1=1;        
	PT1=1;       
	addlok(add);
}
/*******************************************************************************
* Function Name  : ADSTAR
* Description    : ����AD
* Input          : None
* Output         : None
* Return         : None
* DATA           : 2014/11/24
* programmer     : piaoran QQ:384710930
* remark         ��ADSTAR();
*******************************************************************************/
void ADSTAR(void)
{
	START = 0;  //������
	START = 1;
	START = 0;
}
void voltag(void) interrupt 3
{
 	CLK = !CLK;
}
