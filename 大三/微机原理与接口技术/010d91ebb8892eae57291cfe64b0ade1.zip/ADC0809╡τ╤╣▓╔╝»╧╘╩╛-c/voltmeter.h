#include<reg52.h>
#define ADC_P P1
#define ADC_ADDP P2
sbit ADC_0=P2^3;
sbit ADC_1=P2^4;
sbit ADC_2=P2^5;
sbit OE=P2^6;
sbit START=P2^7;
sbit CLK=P3^0;
sbit ALE=P3^1;
sbit EOC=P3^2;

extern float volta,VREF;
void led_displa_voltag(float voltag);
void addlok(unsigned char add);
void ADINIT(unsigned char add);
void ADSTAR(void);