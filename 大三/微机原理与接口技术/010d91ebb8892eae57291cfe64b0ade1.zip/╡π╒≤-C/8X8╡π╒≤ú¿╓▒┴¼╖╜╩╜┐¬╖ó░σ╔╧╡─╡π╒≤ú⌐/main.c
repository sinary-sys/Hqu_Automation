#include<reg52.h>
#include"delay.h"
#include"8X8LED.h"
#include <intrins.h>
void main(void)
{
	unsigned char i=' ';
	unsigned short int j=100;
	while(1)
	{
		while(j--)
		{
		  LED_direct_8X8Char(i);
		}
		j=50;
		i++;
		if(i>='~') i=' ';
		
//		LED_direct_8X8Char('~');
//		LED_direct_8X8Char(0X2D);
	}
}
