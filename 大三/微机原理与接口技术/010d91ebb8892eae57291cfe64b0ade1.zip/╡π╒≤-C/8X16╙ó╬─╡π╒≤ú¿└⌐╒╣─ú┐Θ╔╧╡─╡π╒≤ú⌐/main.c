#include<reg52.h>
#include"delay.h"
#include"8X8LED.h"
#include<ABSACC.h>
#include <intrins.h>
sfr AUXR=0X8E;   //�����Ĵ���
void main(void)
{
	unsigned char i=' ';
	unsigned short int j=200;
	AUXR=0x02;   //��ֹ�ڲ�RAM
	while(1)
	{
		while(j--)
		{
		  LED_8X16Char(i);
		}
		j=200;
		i++;
		if(i>='~') i=' ';
	}
}
