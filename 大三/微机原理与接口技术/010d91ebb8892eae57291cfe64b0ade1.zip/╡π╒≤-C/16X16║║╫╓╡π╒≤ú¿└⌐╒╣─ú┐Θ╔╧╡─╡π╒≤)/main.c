#include<reg52.h>
#include"delay.h"
#include"8X8LED.h"
#include<ABSACC.h>
#include <intrins.h>
#include"FONT8X8.h"
sfr AUXR=0X8E;   //�����Ĵ���
void main(void)
{
	unsigned short int *i=Chinese;
	unsigned short int j,k=500;
	AUXR=0x02;   //��ֹ�ڲ�RAM
	while(1)
	{
		for(j=0;j<6;j++)
		{
			while(k--)
			{
		    LED_16X16Char(i);
			}
			k=500;
			i+=16;
		}
		i=Chinese;
	}
}
