#define LED_wei P0
sbit LED138_0=P2^0;
sbit LED138_1=P2^1;
sbit LED138_2=P2^2;
extern unsigned char code numtab[17];
extern unsigned short int timenum;  //�����ˢ�²��� ��ʱ����װ��ֵ
void led_Static_display(unsigned char wei,unsigned char num);
void led_display_decimalism(unsigned long int number,unsigned char wei,unsigned char num,unsigned char delayus);
void led_display_hexadecimal(unsigned long int number,unsigned char wei,unsigned char num,unsigned char delayus);

