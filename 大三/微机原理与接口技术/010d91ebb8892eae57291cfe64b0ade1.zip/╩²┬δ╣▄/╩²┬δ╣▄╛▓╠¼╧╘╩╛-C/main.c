#include<reg52.h>
#include"delay.h"
#include"KEY.h"
#include"led-display.h"
signed char num=0;  //��ΪҪ����������С ��������ط��������з��ŵ���
void main(void)
{
	unsigned char i=0,temp=0;
	unsigned short int j=0XFFF;
	while(1)
	{
//		P0=numtab[i];
//		delay_ms(500);
//		i++;
//		if(i>9)
//		{
//	    i=0;
//		}
		
//		while(j--)
//		{
//			if(!key1)
//			{
//				j=0;
//				temp=1;
//			}
//			else if(!key2)
//			{
//				j=0;
//				temp=2;
//			}
//			else if(!key3)
//			{
//				j=0;
//				temp=3;
//			}
//			else if(!key4)
//			{
//				j=0;
//				temp=4;
//			}
//	  }
//		j=0XFFF;
//		if(temp==1)
//		{
//			P0=numtab[i];
//			delay_ms(500);
//			i++;
//			if(i>9)
//			{
//				i=0;
//			}
//		}
//		if(temp==2)
//		{
//			P0=numtab[i];
//			delay_ms(500);
//			i--;
//			if((i==0)||(i>9))
//			{
//				i=9;
//			}
//		}
     for(i=0;i<9;i++)
		 {
				P0=numtab[i];
				delay_ms(500);
		 }
	}
}
