#include <reg52.h>
#include"delay.h"
#include"NRF24L01.H"
#include"led-display.h"
unsigned char TxBuf[32];  
sbit KEY1=P3^2;
void main(void)
{
	unsigned char led_num=0X00; 
	init_NRF24L01();
	time_init(timenum);   //�����ɨ�躯��
	while(1)
	{
		if(KEY1 ==0 )   
		{
			led_num++; 
			TxBuf[1]=led_num ;
			nRF24L01_TxPacket(TxBuf); // Transmit Tx buffer data     
			delay_ms(500);	
		}
	}
}