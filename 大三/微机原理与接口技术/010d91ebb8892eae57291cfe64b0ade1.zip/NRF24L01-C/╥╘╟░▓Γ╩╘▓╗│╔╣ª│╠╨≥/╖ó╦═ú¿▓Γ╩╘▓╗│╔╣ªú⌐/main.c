#include<reg52.h>
#include"delay.h"
#include"NRF24L01.H"
#include<led-display.h>
void main(void)
{
	unsigned char i;
	init_NRF24L01() ;
	while(1)
	{
    nRF24L01_TxPacket(TxBuf);
		SPI_RW_Reg(WRITE_REG+STATUS,0XFF);
		for(i=0;i<32;i++)
		{
      TxBuf[i] +=1;
      if(TxBuf[i]>=255)
      {
        TxBuf[i]=0;
      }
		}
		delay_ms(1000);	
	}
}
