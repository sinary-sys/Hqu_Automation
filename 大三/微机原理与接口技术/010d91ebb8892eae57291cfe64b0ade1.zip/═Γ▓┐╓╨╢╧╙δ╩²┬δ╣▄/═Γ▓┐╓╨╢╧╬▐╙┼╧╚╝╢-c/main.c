#include<reg52.h>
#include<intrins.h>
#include"led-display.h"
#define uint unsigned int 
#define uchar unsigned char
uchar i,aa;
void delay(uint z);
void main()
{
	EA=1;		//�����ж�
	EX0=1;		//���ⲿ�ж�0
	IT0=1;		//���ⲿ�ж�0��Ϊ���ش�����ʽ		
	aa=0x01;
	P3=0xff;
	while(1)
	{
		led_Static_display(7,aa);
		delay(1000);	
		aa++;
		if(aa==9)
		{
			aa=1;
		}
	}
}
void delay(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);	
}

void exter0( ) interrupt 0   //����ܵ���
{	
	aa=3;
	delay(20);	
	if(P3^2==0)
	{
		for(i=3;i>0;i--,aa--)
		{
			led_Static_display(7,aa);
			delay(500);
			led_Static_display(7,16);
			delay(500);	
		}		
  }
}