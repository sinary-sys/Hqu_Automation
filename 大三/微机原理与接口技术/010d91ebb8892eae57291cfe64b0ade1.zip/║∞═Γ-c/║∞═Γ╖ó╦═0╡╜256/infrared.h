/*���������*/
#define POWER   0X45
#define MODE    0X46  
#define MUTE    0X47
#define PLAY    0X44
#define PREV    0X40  
#define NEXT    0X43
#define EQ      0X07
#define VOLDOWN 0X15  
#define VOLUP   0X09
#define ZERO    0X16
#define CONVER  0X19  
#define USD     0X0D
#define ONE     0X0C
#define TWO     0X18  
#define THREE   0X5E
#define FOUR    0X08
#define FIVE    0X1C  
#define SIX     0X5A
#define SEVEN   0X42
#define EIGHT   0X52  
#define NINE    0X4A

extern unsigned char cou;
extern unsigned char IrValue[4];
extern unsigned char Syscode_one;	
extern unsigned char Syscode_two;	

void Delay140us(unsigned int x);
void IrInit();
void Init(void);
void Send_IR(unsigned char CustomCode);			//����������
