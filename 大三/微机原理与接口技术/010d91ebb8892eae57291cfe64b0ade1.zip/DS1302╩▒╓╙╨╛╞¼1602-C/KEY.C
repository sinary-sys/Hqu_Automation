#include<reg52.h>
#include"KEY.h"
unsigned char key(void)
{
	if(!key1)
//	if(key1==0)
	{
		return(1);
	}
	if(!key2)
	{
		return(2);
	}
	if(!key3)
	{
		return(3);
	}
	if(!key4)
	{
		return(4);
	}
	return(0);
}