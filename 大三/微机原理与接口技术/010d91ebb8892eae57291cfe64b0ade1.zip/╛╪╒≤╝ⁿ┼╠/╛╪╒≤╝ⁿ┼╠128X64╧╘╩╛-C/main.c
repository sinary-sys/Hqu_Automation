#include<reg52.h>
#include"delay.h"
#include<led-display.h>
#include"lcd12864.h"
#include"KEY.H"
void main(void)
{
	unsigned char num=0;  
	LcdInit();	  //Һ����ʼ��
	ClearSree();     //Һ������
	while(1)
	{
		num=KEY_SCAN();
    ShowSreeWord(0,0,1,&num);
	}
}
