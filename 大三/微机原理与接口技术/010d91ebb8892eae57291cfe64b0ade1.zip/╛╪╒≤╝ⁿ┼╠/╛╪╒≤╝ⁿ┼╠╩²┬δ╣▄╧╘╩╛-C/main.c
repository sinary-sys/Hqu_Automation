#include<reg52.h>
#include"delay.h"
#include<led-display.h>
#include"KEY.H"
void main(void)
{
	unsigned char num=0;  
	led_Static_display(7,0);
//	time_init(timenum);
	while(1)
	{
		num=KEY_SCAN();
    led_Static_display(7,num);
	}
}
