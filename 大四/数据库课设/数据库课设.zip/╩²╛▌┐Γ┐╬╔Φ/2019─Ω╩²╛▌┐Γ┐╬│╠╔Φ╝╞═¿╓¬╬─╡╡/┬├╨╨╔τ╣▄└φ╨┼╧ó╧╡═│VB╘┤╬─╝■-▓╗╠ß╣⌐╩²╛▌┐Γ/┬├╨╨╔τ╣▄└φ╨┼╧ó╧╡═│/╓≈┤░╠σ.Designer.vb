﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class 主窗体
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.首页ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.公司简介ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.社长致辞ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.团员服务ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.团员信息维护ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.团员信息查询ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.团员信息报表ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.修改密码ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行团服务ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行团信息维护ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行团信息查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行团ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出游信息ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出游信息查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行路线服务ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行路线ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.路线排行榜ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.旅行路线信息维护ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.首页ToolStripMenuItem, Me.团员服务ToolStripMenuItem, Me.旅行团服务ToolStripMenuItem, Me.出游信息ToolStripMenuItem, Me.旅行路线服务ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(730, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        '首页ToolStripMenuItem
        '
        Me.首页ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.公司简介ToolStripMenuItem, Me.社长致辞ToolStripMenuItem})
        Me.首页ToolStripMenuItem.Name = "首页ToolStripMenuItem"
        Me.首页ToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.首页ToolStripMenuItem.Text = "首页"
        '
        '公司简介ToolStripMenuItem
        '
        Me.公司简介ToolStripMenuItem.Name = "公司简介ToolStripMenuItem"
        Me.公司简介ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.公司简介ToolStripMenuItem.Text = "公司简介"
        '
        '社长致辞ToolStripMenuItem
        '
        Me.社长致辞ToolStripMenuItem.Name = "社长致辞ToolStripMenuItem"
        Me.社长致辞ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.社长致辞ToolStripMenuItem.Text = "社长致辞"
        '
        '团员服务ToolStripMenuItem
        '
        Me.团员服务ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.团员信息维护ToolStripMenuItem, Me.团员信息查询ToolStripMenuItem1, Me.团员信息报表ToolStripMenuItem, Me.修改密码ToolStripMenuItem})
        Me.团员服务ToolStripMenuItem.Name = "团员服务ToolStripMenuItem"
        Me.团员服务ToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.团员服务ToolStripMenuItem.Text = "团员服务"
        '
        '团员信息维护ToolStripMenuItem
        '
        Me.团员信息维护ToolStripMenuItem.Name = "团员信息维护ToolStripMenuItem"
        Me.团员信息维护ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.团员信息维护ToolStripMenuItem.Text = "团员信息维护"
        '
        '团员信息查询ToolStripMenuItem1
        '
        Me.团员信息查询ToolStripMenuItem1.Name = "团员信息查询ToolStripMenuItem1"
        Me.团员信息查询ToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.团员信息查询ToolStripMenuItem1.Text = "团员信息查询"
        '
        '团员信息报表ToolStripMenuItem
        '
        Me.团员信息报表ToolStripMenuItem.Name = "团员信息报表ToolStripMenuItem"
        Me.团员信息报表ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.团员信息报表ToolStripMenuItem.Text = "团员信息报表"
        '
        '修改密码ToolStripMenuItem
        '
        Me.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem"
        Me.修改密码ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.修改密码ToolStripMenuItem.Text = "修改密码"
        '
        '旅行团服务ToolStripMenuItem
        '
        Me.旅行团服务ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.旅行团信息维护ToolStripMenuItem, Me.旅行团信息查询ToolStripMenuItem, Me.旅行团ToolStripMenuItem})
        Me.旅行团服务ToolStripMenuItem.Name = "旅行团服务ToolStripMenuItem"
        Me.旅行团服务ToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.旅行团服务ToolStripMenuItem.Text = "旅行团服务"
        '
        '旅行团信息维护ToolStripMenuItem
        '
        Me.旅行团信息维护ToolStripMenuItem.Name = "旅行团信息维护ToolStripMenuItem"
        Me.旅行团信息维护ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.旅行团信息维护ToolStripMenuItem.Text = "旅行团信息维护"
        '
        '旅行团信息查询ToolStripMenuItem
        '
        Me.旅行团信息查询ToolStripMenuItem.Name = "旅行团信息查询ToolStripMenuItem"
        Me.旅行团信息查询ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.旅行团信息查询ToolStripMenuItem.Text = "旅行团信息查询"
        '
        '旅行团ToolStripMenuItem
        '
        Me.旅行团ToolStripMenuItem.Name = "旅行团ToolStripMenuItem"
        Me.旅行团ToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.旅行团ToolStripMenuItem.Text = "旅行团信息报表"
        '
        '出游信息ToolStripMenuItem
        '
        Me.出游信息ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.出游信息查询ToolStripMenuItem})
        Me.出游信息ToolStripMenuItem.Name = "出游信息ToolStripMenuItem"
        Me.出游信息ToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.出游信息ToolStripMenuItem.Text = "出游信息"
        '
        '出游信息查询ToolStripMenuItem
        '
        Me.出游信息查询ToolStripMenuItem.Name = "出游信息查询ToolStripMenuItem"
        Me.出游信息查询ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.出游信息查询ToolStripMenuItem.Text = "出游信息查询"
        '
        '旅行路线服务ToolStripMenuItem
        '
        Me.旅行路线服务ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.旅行路线ToolStripMenuItem, Me.路线排行榜ToolStripMenuItem, Me.旅行路线信息维护ToolStripMenuItem})
        Me.旅行路线服务ToolStripMenuItem.Name = "旅行路线服务ToolStripMenuItem"
        Me.旅行路线服务ToolStripMenuItem.Size = New System.Drawing.Size(91, 20)
        Me.旅行路线服务ToolStripMenuItem.Text = "旅行路线服务"
        '
        '旅行路线ToolStripMenuItem
        '
        Me.旅行路线ToolStripMenuItem.Name = "旅行路线ToolStripMenuItem"
        Me.旅行路线ToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.旅行路线ToolStripMenuItem.Text = "旅行路线查询"
        '
        '路线排行榜ToolStripMenuItem
        '
        Me.路线排行榜ToolStripMenuItem.Name = "路线排行榜ToolStripMenuItem"
        Me.路线排行榜ToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.路线排行榜ToolStripMenuItem.Text = "旅行路线排行榜"
        '
        '旅行路线信息维护ToolStripMenuItem
        '
        Me.旅行路线信息维护ToolStripMenuItem.Name = "旅行路线信息维护ToolStripMenuItem"
        Me.旅行路线信息维护ToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.旅行路线信息维护ToolStripMenuItem.Text = "旅行路线信息维护"
        '
        '主窗体
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(730, 424)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "主窗体"
        Me.Text = "主窗体"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents 首页ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 公司简介ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 团员服务ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 团员信息维护ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 团员信息查询ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 团员信息报表ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 修改密码ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行团服务ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行团信息维护ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行团信息查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行团ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 出游信息ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行路线服务ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 出游信息查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行路线ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 路线排行榜ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 社长致辞ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 旅行路线信息维护ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
