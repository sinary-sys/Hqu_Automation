﻿Public Class 社长致辞

End Class