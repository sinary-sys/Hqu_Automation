﻿Module Module1
    Public quanxian As Integer = 0

End Module
