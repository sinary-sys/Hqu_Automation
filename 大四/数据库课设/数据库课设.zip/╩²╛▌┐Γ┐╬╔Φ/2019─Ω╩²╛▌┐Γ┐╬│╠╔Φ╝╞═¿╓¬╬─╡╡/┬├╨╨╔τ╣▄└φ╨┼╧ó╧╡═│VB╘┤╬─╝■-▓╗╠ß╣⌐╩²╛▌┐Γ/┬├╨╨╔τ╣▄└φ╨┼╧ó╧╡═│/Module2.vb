﻿Module Module2
    Public qx As Integer = 0
    Public bianshi As Integer = 0
End Module
