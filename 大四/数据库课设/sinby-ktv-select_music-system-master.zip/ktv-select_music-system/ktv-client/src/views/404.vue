<template>
    <div class="notFound">
        找不到页面
    </div>
</template>
<style lang="less" scoped>

</style>