# ktv-client

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run client
```

### Compiles and minifies for production
```
npm run build
```

