/** 
*
*  @author: Mr_Wei 
*  @version: 1.0.0 
*  @description: jwt签证的密钥
*  @Date: 2019/10/16 12:23
*
*/ 

module.exports = {
    "KEYORSECRET":"$keviHpYBJxVXKNcjgw22O193T0OSc8V4u"
}