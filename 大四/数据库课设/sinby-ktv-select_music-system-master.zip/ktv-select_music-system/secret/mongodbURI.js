/** 
*
*  @author: Mr_Wei 
*  @version: 1.0.0 
*  @description: 配置数据库地址
*  @Date: 2019/10/14 17:52
*
*/ 

module.exports = {
    "mongodbURI":"mongodb://localhost:27017/ktv-select_music_system"
    // "mongodbURI":"mongodb://localhost:27017/ktv"  // 测试
}
