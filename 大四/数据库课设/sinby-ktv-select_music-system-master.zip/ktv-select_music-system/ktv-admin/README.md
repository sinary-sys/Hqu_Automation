# ktv-admin

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run admin
```

### Compiles and minifies for production
```
npm run build
```
