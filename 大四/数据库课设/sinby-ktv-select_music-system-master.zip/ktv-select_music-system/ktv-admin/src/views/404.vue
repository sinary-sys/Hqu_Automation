<template>
    <div class="notFound">
        404页面
    </div>
</template>
<script>
export default {
    name:"NotFound"
}
</script>
<style lang="less" scoped>
.notFound{
    color: tomato;
}
</style>